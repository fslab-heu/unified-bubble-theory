function [R,u,dR,du,ddR,ddu]=Universaltheory_Runge(P0,R0,gamma,Pamb,p_ind,rho,dp_ind,Ca,dvel,dCa,vel,grad_p_ind,g,Cd,c, ...
    dt,R_f0,u_f0,dR_f0,du_f0,dR_f,du_f,ddR_f,ddu_f)
R=R_f0+dt*dR_f;
u=u_f0+dt*du_f;
dR=dR_f0+dt*ddR_f;
du=du_f0+dt*ddu_f;

%%%%%%%%%%һ��HH
HH=(P0*(R0/R)^(3*gamma)+2338-Pamb+p_ind)/rho; 
dHH=-(P0*R0^(3*gamma)*3*gamma*R^(-1.0-3.0*gamma)*dR)/rho ...
     +dp_ind/rho;
 
%%%%%%%%%%  Tait��HH 
% n=7;B=3e8;
% p=P0*(R0/R)^(3*gamma);
% dp=P0*R0^(3*gamma)*3*gamma*R^(-1.0-3.0*gamma)*dR;
% HH=(n*(Pamb+B)/(n-1)*( ((p+B)/(Pamb+B))^(1-1/n) -1)+p_ind)/rho; 
% dHH=-(n*(Pamb+B)/(n-1)*(n-1)/n*((p+B)/(Pamb+B))^(-1/n)*dp/(Pamb+B))/rho ...
%      +dp_ind/rho; 

%%%%%%%  ����HH
% % % % HH=c^2*log(1+(p-Pamb)/c^2/rho); 
% % % % dHH=c^2*dp/(c^2*rho+p-Pamb);
 
%%%%%%%%%  JWL
% A=371.2e9; B=3.231e9; C=1.28e9; R1=4.15; R2=0.95; w=0.3; rho0=1630;
% v0=1.2e-3/rho0;  v=4/3*pi*R^3/v0; 
% dV=1/v0*4*pi*R^2*dR;
% p=A*exp(-R1*v) + B*exp(-R2*v) +C*v^(-w-1);
% dp=A*exp(-R1*v)*(-R1*dV) + B*exp(-R2*v)*(-R2*dV) +C*(-w-1)*v^(-w-2)*dV;
% HH=(p-Pamb+p_ind)/rho; 
% dHH=(dp)/rho ...
%      +dp_ind/rho; 

ddu(1:3)=(Ca*R*dvel(1:3)+(3*Ca*dR+dCa*R)*vel(1:3)-R/rho*(grad_p_ind(1:3)+g(1:3)*rho) ...
    -3/8*Cd*(du(1:3)-vel(1:3))*norm(du(1:3)-vel(1:3))-(3*Ca*dR+dCa*R)*du(1:3))/Ca/R;
% ddR=((1+dR/c)*HH+R/c*dHH -1.5*(1-dR/3/c)*dR^2 ...
%  +0.25*(1+dR/c)*norm(du(1:3)-vel(1:3))^2+dot((du(1:3)-vel(1:3)),(ddu(1:3)-dvel(1:3)))*R/2/c)/R/(1-dR/c);

% ddu(1:3)=((1-2*dR/c)*Ca*R*dvel(1:3)+(1-2*dR/c)*(3*Ca*dR+dCa*R)*vel(1:3)-R*ddR_f*vel(1:3)/2/c-R/rho*(grad_p_ind(1:3)+g(1:3)*rho) ...
%     -3/8*Cd*(du(1:3)-vel(1:3))*norm(du(1:3)-vel(1:3))-(1-2*dR/c)*(3*Ca*dR+dCa*R)*du(1:3)+R*ddR_f*du(1:3)/2/c)/Ca/R/(1-2*dR/c);

% NPA = (grad_p_ind(1:3)+g(1:3)*rho);
% ddu(1:3)= ((3*c*rho+5*dR*rho)*(du(1:3)-vel(1:3))*norm(du(1:3)-vel(1:3))^2  ...
%   + (6*dR^3*rho-144*dR^3*rho*Ca-18*c*rho*dR^2+12*HH*c*rho+12*HH*dR*rho+12*R*dHH*rho ...
%   +216*Ca*c*dR^2*rho-72*Ca*c^2*dR*rho-24*R*c^2*dCa*rho-48*R*dCa*dR^2*rho ...
%   +72*R*c*dCa*dR*rho)*(du(1:3)-vel(1:3)) + (24*R*c*dR-24*R*c^2)*NPA ...
%   + (9*Cd*c*dR*rho-9*Cd*c^2*rho)*(du(1:3)-vel(1:3))*norm(du(1:3)-vel(1:3)) ) ...
%   / ( 2*R*rho*(12*Ca*c^2-36*Ca*c*dR+24*Ca*dR^2-7*norm(du(1:3)-vel(1:3))^2) );
% ddu(1:3) = ddu(1:3)+ dvel(1:3);
ddR=((1+dR/c)*HH+R/c*dHH -1.5*(1-dR/3/c)*dR^2 ...
 )/R/(1-dR/c);

%%gilmore
% ddR=((1+dR/c)*HH+(1-dR/c)*R/c*dHH ...
%  -1.5*(1-dR/3/c)*dR^2)/R/(1-dR/c);


end

