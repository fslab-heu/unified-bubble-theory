function [] = plott(ibubble,Rt,i,Ru,p_field_com)

figure
hold on
h1=subplot(2,2,1);     
for n=1:ibubble;
plot(Rt(n,2:i-1,1)*1e0,Rt(n,2:i-1,2)*1e0,'linewidth',2)        
hold on         
end
grid on
xlabel('$t/\rm{s}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
ylabel('$R/\rm{m}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
set(gca,'LineWidth',1);           
set(gca,'GridLineStyle','--','gridalpha',0.5,'FontName','Times New Roman','FontSize',17)

% for ii=1:ibubble
% Name = strcat('output\','bubble_',num2str(ii),'.dat');
% AA=fopen(Name,'wt');
% fprintf(AA,'%s  %s  %s  %s  %s  %s  %s  %s  %sf\n','t','R','dR','ddR','H','dH','u','v','w') 
% for jj=1:length(Rt(ii,1:i-1,1))
% fprintf(AA,'%8f, %8f, %8f, %8f, %8f, %8f, %8f, %8f, %8f\n',Rt(ii,jj,1),Rt(ii,jj,2),Rt(ii,jj,3),Rt(ii,jj,4),Rt(ii,jj,5),Rt(ii,jj,6),Ru(ii,jj,1),Ru(ii,jj,2),Ru(ii,jj,3)) 
% end
% end



h2=subplot(2,2,2);
for n=1:ibubble;
% plot(Rt(n,1:i-1,1),-Ru(n,1:i-1,1))
% hold on
% plot(Rt(n,1:i-1,1),Ru(n,1:i-1,3))
% hold on
plot(Rt(n,1:i-1,1)*1e0,Ru(n,1:i-1,3)*1e0,'linewidth',2)
hold on
end
grid on
xlabel('$t/\rm{s}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
ylabel('$Pos_z/\rm{m}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
set(gca,'LineWidth',1);
set(gca,'GridLineStyle','--','gridalpha',1,'FontName','Times New Roman','FontSize',15)

h3=subplot(2,2,3);
for n=1:ibubble;
% plot(Rt(n,1:i-1,1),-Ru(n,1:i-1,1))
% hold on
plot(Rt(n,1:i-1,1),Ru(n,1:i-1,2),'linewidth',2)
hold on
% plot(Rt(n,1:i-1,1)*1e0,Ru(n,1:i-1,3)*1e0)
% hold on
end
grid on
xlabel('$t/\rm{s}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
ylabel('$Pos_y/\rm{m}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
set(gca,'LineWidth',1);
set(gca,'GridLineStyle','--','gridalpha',0.2,'FontName','Times New Roman','FontSize',15)

h4=subplot(2,2,4);
plot(Rt(1,2:i-1,1),p_field_com(2:i-1),'linewidth',2)
grid on
% plot(Rt(1,2:i-1,1)/(0.1133*sqrt(1000/394000)),p_field_com(2:i-1)/394000,'linewidth',2)
% grid on
xlabel('$t/\rm{s}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
ylabel('$P/\rm{Pa}$','interpreter','latex','FontName','Times New Roman','FontSize',15)
set(gca,'LineWidth',1);
set(gca,'GridLineStyle','--','gridalpha',0.25,'FontName','Times New Roman','FontSize',15)

set(gcf,'unit','normalized','position',[0.1,0.035,0.600390625,0.805787037037037]);
set(h1,'position',[0.08,0.55,0.4,0.4])
set(h2,'position',[0.565,0.55,0.4,0.4])
% set(h3,'position',[0.198959417273673,0.072413793103448,0.6,0.4])
set(h4,'position',[0.565,0.072,0.4,0.4])
set(h3,'position',[0.085,0.072,0.4,0.4])

         

% B=get(gco,'xdata');
% C=get(gco,'ydata');
% % [r]=find(B>0&B<=8e-5); 
% % [r]=find(B>0.05&B<=0.052);
% [r]=find(B>0.033&B<=0.0412); 
% Es=0;
% for i=1:length(r)
%    Es=Es+4*3.1415*(3.0^2+3.0^2)*(B(r(i)+1)-B(r(i)))*(C(r(i))+5078)^2/1000/1500;
% end
% Es
% Eb=4*3.1415/3.0*0.295^3*1.0*10^5; 

% legend('$d_{\rm{b}}=0.5$','$d_{\rm{b}}=1.0$','$d_{\rm{b}}=1.5$','$d_{\rm{b}}=0.8$','$d_{\rm{b}}=0.6$','$d_{\rm{b}}=0.4$','interpreter','latex','FontName','Times New Roman','FontSize',15)
% legend('$W=0.16g$','$W=0.28g$','$W=0.44g$','$W=0.65g$','$W=0.92g$','$d_{\rm{b}}=0.4$','interpreter','latex','FontName','Times New Roman','FontSize',15)
% legend('$Num=1$','$Num=3$','$Num=5$','$Num=7$','$Num=9$','$Num=11$','$Num=13$','$Num=15$','$Num=16$','$Num=17$','interpreter','latex','FontName','Times New Roman','FontSize',15)

%% figure
end
% A=importdata('D:\paper\ziyoucunderexplosion\UniveralBubbleTheory_0122\UniveralBubbleTheory\pressure.dat')
% plot(A.data(:,1),A.data(:,2))