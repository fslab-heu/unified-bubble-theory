function [R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

for k=1:ibubble;
   
if migration==0;    
u(1:ibubble,1:3)=0;du(1:ibubble,1:3)=0;ddu(1:ibubble,1:3)=0;    
end
   
ddR1=ddR; ddu1=ddu; dR1=dR; du1=du; R1=R; u1=u;   
[R2(k),u2(k,1:3),dR2(k),du2(k,1:3),ddR2(k),ddu2(k,1:3)]=Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
    0.5*dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR1(k),du1(k,1:3),ddR1(k),ddu1(k,1:3));   
[R3(k),u3(k,1:3),dR3(k),du3(k,1:3),ddR3(k),ddu3(k,1:3)]=Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
    0.5*dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR2(k),du2(k,1:3),ddR2(k),ddu2(k,1:3));  
[R4(k),u4(k,1:3),dR4(k),du4(k,1:3),ddR4(k),ddu4(k,1:3)]=Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
    1.0*dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR3(k),du3(k,1:3),ddR3(k),ddu3(k,1:3)); 

 R(k)=R(k)+1/6*dt*(dR1(k)+2*dR2(k)+2*dR3(k)+dR4(k));
 dR(k)=dR(k)+1/6*dt*(ddR1(k)+2*ddR2(k)+2*ddR3(k)+ddR4(k));
 u(k,1:3)=u(k,1:3)+1/6*dt*(du1(k,1:3)+2*du2(k,1:3)+2*du3(k,1:3)+du4(k,1:3));
 du(k,1:3)=du(k,1:3)+1/6*dt*(ddu1(k,1:3)+2*ddu2(k,1:3)+2*ddu3(k,1:3)+ddu4(k,1:3));
HH(k)=(P0(k)*(R0(k)/R(k))^(3*gamma)+2338-Pamb(k)+p_ind(k))/rho; 
dHH(k)=-(P0(k)*R0(k)^(3*gamma)*3*gamma*R(k)^(-1.0-3.0*gamma)*dR(k))/rho ...
     +dp_ind(k)/rho;

%%%%%%%%%  JWL
% A=371.2e9; B=3.231e9; C=1.28e9; R1=4.15; R2=0.95; w=0.3; rho0=1630;
% v0=1.2e-3/rho0;  v=4/3*pi*R^3/v0; 
% dV=1/v0*4*pi*R^2*dR;
% p=A*exp(-R1*v) + B*exp(-R2*v) +C*v^(-w-1);
% dp=A*exp(-R1*v)*(-R1*dV) + B*exp(-R2*v)*(-R2*dV) +C*(-w-1)*v^(-w-2)*dV;
% HH=(p-Pamb+p_ind)/rho; 
% dHH=(dp)/rho ...
%      +dp_ind/rho; 

ddu(k,1:3)=(Ca*R(k)*dvel(k,1:3)+(3*Ca*dR(k)+dCa*R(k))*vel(k,1:3)-R(k)/rho*(grad_p_ind(k,1:3)+g(1:3)*rho) ...
    -3/8*Cd*(du(k,1:3)-vel(k,1:3))*norm(du(k,1:3)-vel(k,1:3))-(3*Ca*dR(k)+dCa*R(k))*du(k,1:3))/Ca/R(k);
% ddR(k)=((1+dR(k)/c)*HH(k)+R(k)/c*dHH(k) ...
%  -1.5*(1-dR(k)/3/c)*dR(k)^2+0.25*(1+dR(k)/c)*norm(du(k,1:3)-vel(k,1:3))^2+dot((du(k,1:3)-vel(k,1:3)),(ddu(k,1:3)-dvel(k,1:3)))*R(k)/2/c)/R(k)/(1-dR(k)/c);

% ddu(k,1:3)=((1-2*dR(k)/c)*Ca*R(k)*dvel(k,1:3)+(1-2*dR(k)/c)*(3*Ca*dR(k)+dCa*R(k))*vel(k,1:3)-R(k)*ddR4(k)*vel(k,1:3)/2/c-R(k)/rho*(grad_p_ind(k,1:3)+g(1:3)*rho) ...
%     -3/8*Cd*(du(k,1:3)-vel(k,1:3))*norm(du(k,1:3)-vel(k,1:3))-(1-2*dR(k)/c)*(3*Ca*dR(k)+dCa*R(k))*du(k,1:3)+R(k)*ddR4(k)*du(k,1:3)/2/c)/Ca/R(k)/(1-2*dR(k)/c);

% NPA = (grad_p_ind(k,1:3)+g(1:3)*rho);
% ddu(k,1:3)= ((3*c*rho+5*dR(k)*rho)*(du(k,1:3)-vel(k,1:3))*norm(du(k,1:3)-vel(k,1:3))^2  ...
%   + (6*dR(k)^3*rho-144*dR(k)^3*rho*Ca-18*c*rho*dR(k)^2+12*HH(k)*c*rho+12*HH(k)*dR(k)*rho+12*R(k)*dHH(k)*rho ...
%   +216*Ca*c*dR(k)^2*rho-72*Ca*c^2*dR(k)*rho-24*R(k)*c^2*dCa*rho-48*R(k)*dCa*dR(k)^2*rho ...
%   +72*R(k)*c*dCa*dR(k)*rho)*(du(k,1:3)-vel(k,1:3)) + (24*R(k)*c*dR(k)-24*R(k)*c^2)*NPA ...
%   + (9*Cd*c*dR(k)*rho-9*Cd*c^2*rho)*(du(k,1:3)-vel(k,1:3))*norm(du(k,1:3)-vel(k,1:3)) ) ...
%   / ( 2*R(k)*rho*(12*Ca*c^2-36*Ca*c*dR(k)+24*Ca*dR(k)^2-7*norm(du(k,1:3)-vel(k,1:3))^2) );
% ddu(k,1:3) = ddu(k,1:3)+ dvel(k,1:3);
ddR(k)=((1+dR(k)/c)*HH(k)+R(k)/c*dHH(k) ...
 -1.5*(1-dR(k)/3/c)*dR(k)^2)/R(k)/(1-dR(k)/c);

%%%gilmore
% ddR(k)=((1+dR(k)/c)*HH(k)+(1-dR(k)/c)*R(k)/c*dHH(k) ...
%  -1.5*(1-dR(k)/3/c)*dR(k)^2)/R(k)/(1-dR(k)/c);

pos(k,1:3)=pos(k,1:3)+dt*du(k,1:3);


% ddR1=ddR; ddu1=ddu; dR1=dR; du1=du; R1=R; u1=u;   
% [R2(k),u2(k,1:3),dR2(k),du2(k,1:3),ddR2(k),ddu2(k,1:3)]=Universaltheory_Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
%     0.5*dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR1(k),du1(k,1:3),ddR1(k),ddu1(k,1:3));   
% [R3(k),u3(k,1:3),dR3(k),du3(k,1:3),ddR3(k),ddu3(k,1:3)]=Universaltheory_Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
%     dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR2(k),du2(k,1:3),ddR2(k),ddu2(k,1:3));  
% % % [R4(k),u4(k,1:3),dR4(k),du4(k,1:3),ddR4(k),ddu4(k,1:3)]=Universaltheory_Runge(P0(k),R0(k),gamma,Pamb(k),p_ind(k),rho,dp_ind(k),Ca,dvel(k,1:3),dCa,vel(k,1:3),grad_p_ind(k,1:3),g,Cd,c, ...
% % %     1.0*dt,R1(k),u1(k,1:3),dR1(k),du1(k,1:3),dR3(k),du3(k,1:3),ddR3(k),ddu3(k,1:3)); 
% 
%  R(k)=R3(k);
%  dR(k)=dR3(k);
%  u(k,1:3)=u3(k,1:3);
%  du(k,1:3)=du3(k,1:3);
% HH(k)=(P0(k)*(R0(k)/R(k))^(3*gamma)-Pamb(k)+p_ind(k))/rho; 
% dHH(k)=-(P0(k)*R0(k)^(3*gamma)*3*gamma*R(k)^(-1.0-3.0*gamma)*dR(k))/rho ...
%      +dp_ind(k)/rho;
% ddu(k,1:3)=(Ca*R(k)*dvel(k,1:3)+(3*Ca*dR(k)+dCa*R(k))*vel(k,1:3)-R(k)/rho*(grad_p_ind(k,1:3)+g(1:3)*rho) ...
%     -3/8*Cd*(du(k,1:3)-vel(k,1:3))*norm(du(k,1:3)-vel(k,1:3))-(3*Ca*dR(k)+dCa*R(k))*du(k,1:3))/Ca/R(k);
% ddR(k)=((1+dR(k)/c)*HH(k)+R(k)/c*dHH(k) ...
%  -1.5*(1-dR(k)/3/c)*dR(k)^2+0.25*(1+dR(k)/c)*norm(du(k,1:3)-vel(k,1:3))^2+dot((du(k,1:3)-vel(k,1:3)),(ddu(k,1:3)-dvel(k,1:3)))*R(k)/2/c)/R(k)/(1-dR(k)/c);
% pos(k,1:3)=pos(k,1:3)+dt*du(k,1:3);


end

if migration==0;    
u(1:ibubble,1:3)=0;du(1:ibubble,1:3)=0;ddu(1:ibubble,1:3)=0;    
end

end

