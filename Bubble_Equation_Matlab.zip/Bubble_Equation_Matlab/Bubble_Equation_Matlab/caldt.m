function [dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma)
global ibubble

for i=1:ibubble;
delta(i)=Pamb(i)/rho+P0(i)*(R0(i)/R(i))^(3*gamma)/rho+0.5*dR(i)^2;
end

dt=sdt/min(delta);
if dt>sdt
   dt=sdt;
end 

end

