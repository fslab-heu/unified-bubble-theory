function [vel,dvel,p_ind,dp_ind,grad_p_ind] = singleboundary(boun_pos,t,R,pos,norm_boun,alpha,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

for k=1:ibubble;
velb(k,1:3)=0;
dvelb(k,1:3)=0;
p_indb(k)=0;
dp_indb(k)=0;
grad_p_indb(k,1:3)=0;    
    for j=1:ibubble;
         m=ibubble+j;
         boun=dot((boun_pos(1:3)-pos(j,1:3)),norm_boun(1:3));
         pos(m,1:3)=2*boun*norm_boun(1:3)+pos(j,1:3);
         DD=norm(pos(m,1:3)-pos(k,1:3));
         nor=(pos(m,1:3)-pos(k,1:3))/DD;
         tyc=t-(DD-R(j))/c;
         if tyc>0/10000&&i>3;             %���ʱ���ӳ�������
           Ryc=interp1(Rt(j,2:i-1,1),Rt(j,2:i-1,2),tyc,'spline');
           dRyc=interp1(Rt(j,2:i-1,1),Rt(j,2:i-1,3),tyc,'spline');
           ddRyc=interp1(Rt(j,2:i-1,1),Rt(j,2:i-1,4),tyc,'spline');
           HHyc=interp1(Rt(j,2:i-1,1),Rt(j,2:i-1,5),tyc,'spline');
           dHHyc=interp1(Rt(j,2:i-1,1),Rt(j,2:i-1,6),tyc,'spline');
         else
           Ryc=0;
           dRyc=0;
           ddRyc=0;
           HHyc=0;
           dHHyc=0;
         end        
         velb(k,1:3)=velb(k,1:3)-Ryc/DD^2*((DD-Ryc)/c*(HHyc+0.5*dRyc^2)+Ryc*dRyc)*nor;
         dvelb(k,1:3)=dvelb(k,1:3)-(2*Ryc*dRyc^2+Ryc^2*ddRyc)/DD^2*nor ...
    -((DD*dRyc-2*Ryc*dRyc)*(HHyc+0.5*dRyc^2)+(DD*Ryc-Ryc^2)*(dHHyc+dRyc*ddRyc))/c/DD^2*nor;
         p_indb(k)=p_indb(k)-rho*(Ryc/DD*(HHyc+0.5*dRyc^2));
         dp_indb(k)=dp_indb(k)-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD;
         grad_p_indb(k,1:3)=grad_p_indb(k,1:3)-(nor*(-rho*(Ryc/DD*(HHyc+0.5*dRyc^2)))/DD ...
             +nor*(-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD)/c);          
         
    end    

         vel(k,1:3)=vel(k,1:3)+alpha*velb(k,1:3);        %%%%%%%induce��Ϣ+�߽���Ϣ
         dvel(k,1:3)=dvel(k,1:3)+alpha*dvelb(k,1:3);
         p_ind(k)=p_ind(k)+alpha*p_indb(k);     
         dp_ind(k)=dp_ind(k)+alpha*dp_indb(k);    
         grad_p_ind(k,1:3)=grad_p_ind(k,1:3)+alpha*grad_p_indb(k,1:3);           
         
         p_ind(k)=p_ind(k)+0.5*rho*norm(vel(k,1:3))^2;
         dp_ind(k)=dp_ind(k)+rho*dot(vel(k,1:3),dvel(k,1:3));
end
 
end

