function [p_field_com,phit,uuf] = cal_pressure_gravity(pos,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

p_field_com(:,1:i-1) = p_field_com(:,1:i-1);
phit(:,1:i-1) = phit(:,1:i-1);
uuf(:,1:i-1,1) = uuf(:,1:i-1,1);
uuf(:,1:i-1,2) = uuf(:,1:i-1,2);
uuf(:,1:i-1,3) = uuf(:,1:i-1,3);
for mm=1:ibubble;
  r=norm(pos(mm,1:3)-pressure_loc(1:3));
  phit(mm,i)=R(mm)/r*(HH(mm)+0.5*dR(mm)^2);
  uuf(mm,i,1:3)=R(mm)/r^2*(R(mm)*dR(mm)+(r-R(mm))/c*(HH(mm)+0.5*dR(mm)^2)) * (pressure_loc(1:3)-pos(mm,1:3))/r;
    if t-(r-R(mm))/c>0 && i>3 
       phit_com(mm,i)=interp1(Rt(mm,2:i-1,1),phit(mm,2:i-1),t-(r-R(mm))/c,'linear');
       uuf_com(mm,i,1)=interp1(Rt(mm,2:i-1,1),uuf(mm,2:i-1,1),t-(r-R(mm))/c,'linear');
       uuf_com(mm,i,2)=interp1(Rt(mm,2:i-1,1),uuf(mm,2:i-1,2),t-(r-R(mm))/c,'linear');
       uuf_com(mm,i,3)=interp1(Rt(mm,2:i-1,1),uuf(mm,2:i-1,3),t-(r-R(mm))/c,'linear');
    else
       phit_com(mm,i)=0;
       uuf_com(mm,i,1:3)=0;
    end
end

vel_all(1)=sum( uuf_com(:,i,1) );
vel_all(2)=sum( uuf_com(:,i,2) );
vel_all(3)=sum( uuf_com(:,i,3) );
% p_field_com(i)=Pref+rho*abs(g(3))*abs(pressure_loc(3)) + rho*sum( phit_com(:,i) ) -0.5*rho*norm(vel_all(1:3))^2;
p_field_com(i)= rho*sum( phit_com(:,i) ) -0.5*rho*norm(vel_all(1:3))^2;

end
