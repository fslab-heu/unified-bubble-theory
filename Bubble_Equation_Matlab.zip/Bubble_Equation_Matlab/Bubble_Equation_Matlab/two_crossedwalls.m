function [vel,dvel,p_ind,dp_ind,grad_p_ind] = two_crossedwalls(boun_pos,t,R,pos,norm_boun,alpha,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

%%
dis_h = -0.4;
dis_v = -0.4;
%%����֮��ļн�
cross_angle = pi/2;
%%%ˮƽ�߽編��
norm_h(1:3) = [0,0,-1];   %%%% ����
%%%���ӵ�����
cross_point = [0,pos(1,2)+dis_v,pos(1,3)+dis_h];

if i==2;
plot([pos(1,2)+dis_v,pos(1,2)+dis_v+4],[pos(1,3)+dis_h,pos(1,3)+dis_h],'b')
hold on
plot([pos(1,2)+dis_v,pos(1,2)+dis_v],[pos(1,3)+dis_h,pos(1,3)+dis_h+4],'b')
hold on
end
for aa=1:ibubble;
  if mod(i,50)==0;

    alph=0:pi/40:2*pi;
    x = 0.02*cos(alph);
    y = 0.02*sin(alph);
    plot(pos(aa,2)+x,pos(aa,3)+y,'-')
    axis equal
  end
end
    
%%%��������
kk = 2*(pi/(cross_angle))-1;

for f = 1:ibubble;
   %%%yu���ӵ�juli
   dis_cross = norm(pos(f,1:3)-cross_point(1:3));
   %%%������ڵ����ߺ�ˮƽ�߽��ļн�
   angle(1) =  acos(dot((pos(f,1:3)-cross_point(1:3)), [1,0,0])/dis_cross); 
   angle(2) =  acos(dot((pos(f,1:3)-cross_point(1:3)), [0,1,0])/dis_cross);
   angle(3) =  acos(dot((pos(f,1:3)-cross_point(1:3)), [0,0,1])/dis_cross);
    for j = 1:pi/cross_angle-1;
       pos(ibubble+kk*(f-1)+j,1) = cross_point(1)+0;
       pos(ibubble+kk*(f-1)+j,2) = cross_point(2)+dis_cross*cos( angle(2)+2*j*cross_angle );
       pos(ibubble+kk*(f-1)+j,3) = cross_point(3)+dis_cross*sin( angle(2)+2*j*cross_angle );
       R_mir(ibubble+kk*(f-1)+j) = R(f);
       i_mir(ibubble+kk*(f-1)+j) = f;
    end
    for j = pi/cross_angle:kk;
       pos(ibubble+kk*(f-1)+j,1) = cross_point(1)+0;
       pos(ibubble+kk*(f-1)+j,2) = cross_point(2)+dis_cross*cos( -angle(2)-2*(j-pi/cross_angle)*cross_angle );
       pos(ibubble+kk*(f-1)+j,3) = cross_point(3)+dis_cross*sin( -angle(2)-2*(j-pi/cross_angle)*cross_angle );
       R_mir(ibubble+kk*(f-1)+j) = R(f);
       i_mir(ibubble+kk*(f-1)+j) = f;
    end
end

for k=1:ibubble;
velb(k,1:3)=0;
dvelb(k,1:3)=0;
p_indb(k)=0;
dp_indb(k)=0;
grad_p_indb(k,1:3)=0;  
    for j=1:ibubble*kk;
         m=ibubble+j;
         DD=norm(pos(m,1:3)-pos(k,1:3));
         nor=(pos(m,1:3)-pos(k,1:3))/DD;
         tyc=t-(DD-R_mir(m))/c;
         if tyc>0/10000&&i>3;             %���ʱ���ӳ�������
           Ryc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,2),tyc,'spline');
           dRyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,3),tyc,'spline');
           ddRyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,4),tyc,'spline');
           HHyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,5),tyc,'spline');
           dHHyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,6),tyc,'spline');
         else
           Ryc=0;
           dRyc=0;
           ddRyc=0;
           HHyc=0;
           dHHyc=0;
         end        
         velb(k,1:3)=velb(k,1:3)-Ryc/DD^2*((DD-Ryc)/c*(HHyc+0.5*dRyc^2)+Ryc*dRyc)*nor;
         dvelb(k,1:3)=dvelb(k,1:3)-(2*Ryc*dRyc^2+Ryc^2*ddRyc)/DD^2*nor ...
    -((DD*dRyc-2*Ryc*dRyc)*(HHyc+0.5*dRyc^2)+(DD*Ryc-Ryc^2)*(dHHyc+dRyc*ddRyc))/c/DD^2*nor;
         p_indb(k)=p_indb(k)-rho*(Ryc/DD*(HHyc+0.5*dRyc^2));
         dp_indb(k)=dp_indb(k)-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD;
         grad_p_indb(k,1:3)=grad_p_indb(k,1:3)-(nor*(-rho*(Ryc/DD*(HHyc+0.5*dRyc^2)))/DD ...
             +nor*(-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD)/c);         
         
    end    

         vel(k,1:3)=vel(k,1:3)+alpha*velb(k,1:3);        %%%%%%%induce��Ϣ+�߽���Ϣ
         dvel(k,1:3)=dvel(k,1:3)+alpha*dvelb(k,1:3);
         p_ind(k)=p_ind(k)+alpha*p_indb(k);     
         dp_ind(k)=dp_ind(k)+alpha*dp_indb(k);    
         grad_p_ind(k,1:3)=grad_p_ind(k,1:3)+alpha*grad_p_indb(k,1:3);           
         
         p_ind(k)=p_ind(k)+0.5*rho*norm(vel(k,1:3))^2;
         dp_ind(k)=dp_ind(k)+rho*dot(vel(k,1:3),dvel(k,1:3));
end
 
end

