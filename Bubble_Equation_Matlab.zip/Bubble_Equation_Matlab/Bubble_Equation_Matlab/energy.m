function [Ekp,Ekm,Epoten] = energy(R,dR,ddR,rho,u,du,Pamb,P0,R0)
%ENERGY �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
global ibubble
for i=1:ibubble

V(i) = 4/3*pi*R(i)^3; dV(i) = 4*pi*R(i)^2*dR(i); 
ddV(i) = 4*pi*(2*R(i)*dR(i)^2+R(i)^2*ddR(i));

Ekp(i) = 0.5*rho*(4*pi*R(i)^2*R(i)*dR(i)^2);
Ekm(i)=0.5*rho*(du(i,3)^2*R(i)/2*4*pi/3*R(i)^2);
Epoten(i) = Pamb(i)*V(i)+P0(i)*(R0(i)/R(i))^(3*1.25)*V(i)/(1.25-1);
% Ea(i) = rho/4/pi/c*( dV0(i)*ddV0(i) - dV(i)*ddV(i) + inte );

end

end

