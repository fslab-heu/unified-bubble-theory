function [vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary)

for k=1:ibubble;
vel(k,1:3)=0;
dvel(k,1:3)=0;
p_ind(k)=0;
dp_ind(k)=0;
grad_p_ind(k,1:3)=0;
   for m=1:ibubble ;
      if m~=k 
         DD=norm(pos(m,1:3)-pos(k,1:3));
         nor=(pos(m,1:3)-pos(k,1:3))/DD;
         tyc=t-(DD-R(m))/c;
         if tyc>0/100000 && i>=3;             %���ʱ���ӳ�������
           Ryc=interp1(Rt(m,2:i-1,1),Rt(m,2:i-1,2),tyc,'linear');
           dRyc=interp1(Rt(m,2:i-1,1),Rt(m,2:i-1,3),tyc,'linear');
           ddRyc=interp1(Rt(m,2:i-1,1),Rt(m,2:i-1,4),tyc,'linear');
           HHyc=interp1(Rt(m,2:i-1,1),Rt(m,2:i-1,5),tyc,'linear');
           dHHyc=interp1(Rt(m,2:i-1,1),Rt(m,2:i-1,6),tyc,'linear');
         else
           Ryc=0;
           dRyc=0;
           ddRyc=0;
           HHyc=0;
           dHHyc=0;
         end        
         vel(k,1:3)=vel(k,1:3)-Ryc/DD^2*((DD-Ryc)/c*(HHyc+0.5*dRyc^2)+Ryc*dRyc)*nor;
         dvel(k,1:3)=dvel(k,1:3)-(2*Ryc*dRyc^2+Ryc^2*ddRyc)/DD^2*nor ...
    -((DD*dRyc-2*Ryc*dRyc)*(HHyc+0.5*dRyc^2)+(DD*Ryc-Ryc^2)*(dHHyc+dRyc*ddRyc))/c/DD^2*nor;
         p_ind(k)=p_ind(k)-rho*(Ryc/DD*(HHyc+0.5*dRyc^2));
         dp_ind(k)=dp_ind(k)-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD;
         grad_p_ind(k,1:3)=grad_p_ind(k,1:3)-(nor*(-rho*(Ryc/DD*(HHyc+0.5*dRyc^2)))/DD ...
             +nor*(-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD)/c);   
      end
   end

       if boundary==0;
         p_ind(k)=p_ind(k)+0.5*rho*norm(vel(k,1:3))^2;
         dp_ind(k)=dp_ind(k)+rho*dot(vel(k,1:3),dvel(k,1:3));
       end    
   
end   



end

