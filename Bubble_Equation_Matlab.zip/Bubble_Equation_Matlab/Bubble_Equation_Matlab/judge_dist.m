function [iDD] = judge_dist(R,pos,boundary,boun_pos,norm_boun)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

iDD=0;
for x=1:ibubble;
    if boundary==0;
    for y=1:ibubble
        if x~=y&&R(x)+R(y)-norm(pos(x,:)-pos(y,:))>1e-5;
           iDD=1; 
        end
    end
    else
        if R(x)-dot((boun_pos(1:3)-pos(x,1:3)),norm_boun(1:3))>1e-5;
        iDD=1;
        end
    end
end



end

