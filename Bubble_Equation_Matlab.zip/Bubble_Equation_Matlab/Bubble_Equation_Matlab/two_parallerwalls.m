function [vel,dvel,p_ind,dp_ind,grad_p_ind,pos,i_mir,alpha_i] = two_parallerwalls(t,R,pos,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i)
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

%%�����߽�֮��ľ��� �� ���������ľ���
dis_bt = 1.2;
dis_b = 0.4;
%% �߽�����
alpha_t=-1.0;    %%%% �ϱ߽�
alpha_b=1.0;     %%%% �±߽�
   
%% ����
num = 10;
for m = 1:ibubble;
poso(m,1,1:2) = pos(m,1:2);
poso(m,1,3) = 2.0*(pos(m,3)-dis_b)-pos(m,3);
R_mir(ibubble+(m-1)*2*num+1) = R(m);
i_mir(ibubble+(m-1)*2*num+1) = m;
alpha_i(ibubble+(m-1)*2*num+1) = alpha_b;

poso(m,num+1,1:2) = pos(m,1:2);
poso(m,num+1,3) = 2.0*(pos(m,3)+dis_bt-dis_b)-pos(m,3);
R_mir(ibubble+(m-1)*2*num+num+1) = R(m);
i_mir(ibubble+(m-1)*2*num+num+1) = m;
alpha_i(ibubble+(m-1)*2*num+num+1) = alpha_t;
end

for m = 1:ibubble;
   for n = 2:num;
       poso(m,n,1:2) = pos(m,1:2);
       poso(m,n,3) = 2.0*(pos(m,3)-dis_b)-poso(m,num+(n-1),3);
       R_mir(ibubble+(m-1)*2*num+n) = R(m);
       i_mir(ibubble+(m-1)*2*num+n) = m;
  alpha_i(ibubble+(m-1)*2*num+n) = alpha_b*alpha_i(ibubble+(m-1)*2*num+num+(n-1));
       
       poso(m,num+n,1:2) = pos(m,1:2);
       poso(m,num+n,3) = 2.0*(pos(m,3)+dis_bt-dis_b)-poso(m,(n-1),3); 
       R_mir(ibubble+(m-1)*2*num+num+n) = R(m);
       i_mir(ibubble+(m-1)*2*num+num+n) = m;
  alpha_i(ibubble+(m-1)*2*num+num+n) = alpha_t*alpha_i(ibubble+(m-1)*2*num+(n-1));     
   end
end

for jj = 1:ibubble;
pos(ibubble+(jj-1)*2*num+1:ibubble+(jj-1)*2*num+num,:)=poso(jj,1:num,:);
pos(ibubble+(jj-1)*2*num+num+1:ibubble+(jj-1)*2*num+num+num,:)=poso(jj,num+1:num+num,:);
end

if i==2;
plot([-2,2],[pos(1,3)-dis_b,pos(1,3)-dis_b],'b')
hold on
plot([-2,2],[pos(1,3)+dis_bt-dis_b,pos(1,3)+dis_bt-dis_b],'b')
hold on
for aa=1:ibubble;
    plot(pos(aa,2),pos(aa,3),'o','markersize',4,'color','r')
    hold on
    axis equal
end

for aa=ibubble+1:ibubble+ibubble*2*num;
    if alpha_i(aa)>0;
     plot(pos(aa,2),pos(aa,3),'o','markersize',4,'color','r')
     hold on
     axis equal
    else
     plot(pos(aa,2),pos(aa,3),'o','markersize',4,'color','b')
     hold on
     axis equal
    end
end

end

%% %������������
kk = 2*num;

%%
for k=1:ibubble;
velb(k,1:3)=0;
dvelb(k,1:3)=0;
p_indb(k)=0;
dp_indb(k)=0;
grad_p_indb(k,1:3)=0;  
    for j=1:ibubble*kk;
         m=ibubble+j;
         DD=norm(pos(m,1:3)-pos(k,1:3));
         nor=(pos(m,1:3)-pos(k,1:3))/DD;
         tyc=t-(DD-R_mir(m))/c;
         if tyc>0/10000&&i>3;             %���ʱ���ӳ�������
           Ryc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,2),tyc,'spline');
           dRyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,3),tyc,'spline');
           ddRyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,4),tyc,'spline');
           HHyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,5),tyc,'spline');
           dHHyc=interp1(Rt(i_mir(m),2:i-1,1),Rt(i_mir(m),2:i-1,6),tyc,'spline');
         else
           Ryc=0;
           dRyc=0;
           ddRyc=0;
           HHyc=0;
           dHHyc=0;
         end        
         velb(k,1:3)=velb(k,1:3)-alpha_i(m)*Ryc/DD^2*((DD-Ryc)/c*(HHyc+0.5*dRyc^2)+Ryc*dRyc)*nor;
         dvelb(k,1:3)=dvelb(k,1:3)-alpha_i(m)*(2*Ryc*dRyc^2+Ryc^2*ddRyc)/DD^2*nor ...
    -alpha_i(m)*((DD*dRyc-2*Ryc*dRyc)*(HHyc+0.5*dRyc^2)+(DD*Ryc-Ryc^2)*(dHHyc+dRyc*ddRyc))/c/DD^2*nor;
         p_indb(k)=p_indb(k)-alpha_i(m)*rho*(Ryc/DD*(HHyc+0.5*dRyc^2));
         dp_indb(k)=dp_indb(k)-alpha_i(m)*rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD;
         grad_p_indb(k,1:3)=grad_p_indb(k,1:3)-alpha_i(m)*(nor*(-rho*(Ryc/DD*(HHyc+0.5*dRyc^2)))/DD ...
             +alpha_i(m)*nor*(-rho*(dRyc*HHyc+Ryc*dHHyc+0.5*dRyc^3+Ryc*dRyc*ddRyc)/DD)/c);         
         
    end       
         vel(k,1:3)=vel(k,1:3)+velb(k,1:3);        %%%%%%%induce��Ϣ+�߽���Ϣ
         dvel(k,1:3)=dvel(k,1:3)+dvelb(k,1:3);
         p_ind(k)=p_ind(k)+p_indb(k);     
         dp_ind(k)=dp_ind(k)+dp_indb(k);    
         grad_p_ind(k,1:3)=grad_p_ind(k,1:3)+grad_p_indb(k,1:3);           
         
         p_ind(k)=p_ind(k)+0.5*rho*norm(vel(k,1:3))^2;
         dp_ind(k)=dp_ind(k)+rho*dot(vel(k,1:3),dvel(k,1:3));
end
 
end

