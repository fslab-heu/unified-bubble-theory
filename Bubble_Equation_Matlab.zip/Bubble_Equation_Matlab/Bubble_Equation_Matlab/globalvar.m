function [] = globalvar( )
global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble


g(1:3)=[0,0,0];
dCa=0;

fid1=fopen('constants.dat','r');

AA = textscan(fid1, '%f %s%s', 10); 
BB=AA{1,1};
gamma=BB(1); c=BB(2); g(3)=-BB(6); rho=BB(7); Cd=BB(8); Ca=BB(9); 
Pref=BB(10);  

AA = textscan(fid1, '%f,%f,%f %s%s', 1);     %%%%%%���������ٶ�

fclose(fid1)


end

