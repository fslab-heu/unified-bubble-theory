%% %%%%%%%% Zhang equation
clear
clear all

global gamma c g rho Cd Ca dCa Pref
global Tend sdt ibubble

%% %%%%%%%%initial parameter
globalvar();
[boundary,alpha,migration,pressure_loc,pos,R0,P0,dR,R,ddR,Pamb,u,du,ddu,Rt,t,i,boun_pos,norm_boun] = initiation( );
phit = 0;uuf(:,:,1:3) = 0; p_field_com(:) = 0;
dis_bt0=0; dis_b0=0; dis_v0=0; Ru=0;
%% % % % 
while(boundary==0&&t<Tend)  %%%%%no boundary
i=i+1;    
[dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma);
dt=1e-4*min(R);   
[vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary);
Pamb=Pref+rho*abs(g(3))*abs(pos(:,3));
% Pamb=Pref-rho*abs(g(3))*abs(u(:,3));
[R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration);

Rt(1:ibubble,i,1)=t; Rt(1:ibubble,i,2)=R(1:ibubble); Rt(1:ibubble,i,3)=dR(1:ibubble); Rt(1:ibubble,i,4)=ddR(1:ibubble);
Rt(1:ibubble,i,5)=HH(1:ibubble); Rt(1:ibubble,i,6)=dHH(1:ibubble);
Ru(1:ibubble,i,1)=u(1:ibubble,1);Ru(1:ibubble,i,2)=u(1:ibubble,2);Ru(1:ibubble,i,3)=u(1:ibubble,3);
Ru(1:ibubble,i,4)=ddu(1:ibubble,3).*du(1:ibubble,3);Ru(1:ibubble,i,5)=ddR(1:ibubble);Ru(1:ibubble,i,6)=R(1:ibubble).*dR(1:ibubble);
[Ekp,Ekm,Epoten] = energy(R,dR,ddR,rho,u,du,Pamb,P0,R0);
Ru(1:ibubble,i,4)= Ekp(1:ibubble); 
Ru(1:ibubble,i,5)= Ekm(1:ibubble); 
Ru(1:ibubble,i,6)= Epoten(1:ibubble);
Ru(1:ibubble,i,7)= Ekp(1:ibubble)+Ekm(1:ibubble)+Epoten(1:ibubble);

t=t+dt  
[p_field_com,phit,uuf] = cal_pressure_gravity(pos,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com);

[iDD]=judge_dist(R,pos,boundary,boun_pos,norm_boun);
if iDD~=0; 
    fprintf('Please check the distance of bubbles');
    break 
end  

end

%%
while(boundary==1&&t<Tend)    %%%%%%single boundary
i=i+1;  
[dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma);
dt=1e-4*min(R);  
Pamb=Pref+rho*abs(g(3))*abs(pos(:,3));
[vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary);
% vel(1:ibubble,1:3)=0;dvel(1:ibubble,1:3)=0;
[vel,dvel,p_ind,dp_ind,grad_p_ind] = singleboundary(boun_pos,t,R,pos,norm_boun,alpha,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i);
[R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration);

Rt(1:ibubble,i,1)=t; Rt(1:ibubble,i,2)=R(1:ibubble); Rt(1:ibubble,i,3)=dR(1:ibubble); Rt(1:ibubble,i,4)=ddR(1:ibubble);
Rt(1:ibubble,i,5)=HH(1:ibubble); Rt(1:ibubble,i,6)=dHH(1:ibubble);Rt(1:ibubble,i,7)=p_ind(1);
Ru(1:ibubble,i,1)=u(1:ibubble,1);Ru(1:ibubble,i,2)=u(1:ibubble,2);Ru(1:ibubble,i,3)=u(1:ibubble,3);
Ru(1:ibubble,i,4)=du(1:ibubble,1);Ru(1:ibubble,i,5)=du(1:ibubble,2);Ru(1:ibubble,i,6)=du(1:ibubble,3);
t=t+dt
[p_field_com,phit,uuf] = cal_pressure_single(pos,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com,alpha,boun_pos,norm_boun);

% [iDD]=judge_dist(R,pos,boundary,boun_pos,norm_boun);
% if iDD~=0; 
%     fprintf('Please check the distance of bubbles');
%     break 
% end  

end

while(boundary==21&&t<Tend)    %%%%%%crossed boundary
i=i+1;  
[dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma);
dt=1e-4*min(R);  
[vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary);
[vel,dvel,p_ind,dp_ind,grad_p_ind] = two_crossedwalls(boun_pos,t,R,pos,norm_boun,alpha,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i);
Pamb=Pref+rho*abs(g(3))*abs(pos(:,3));
[R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration);

Rt(1:ibubble,i,1)=t; Rt(1:ibubble,i,2)=R(1:ibubble); Rt(1:ibubble,i,3)=dR(1:ibubble); Rt(1:ibubble,i,4)=ddR(1:ibubble);
Rt(1:ibubble,i,5)=HH(1:ibubble); Rt(1:ibubble,i,6)=dHH(1:ibubble);
Ru(1:ibubble,i,1)=u(1:ibubble,1);Ru(1:ibubble,i,2)=u(1:ibubble,2);Ru(1:ibubble,i,3)=u(1:ibubble,3);
t=t+dt
[p_field_com,phit,uuf] = cal_pressure_single(pos,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com,alpha,boun_pos,norm_boun);

% [iDD]=judge_dist(R,pos,boundary,boun_pos,norm_boun);
% if iDD~=0; 
%     fprintf('Please check the distance of bubbles');
%     break 
% end  

end

while(boundary==22&&t<Tend)    %%%%%% paraller
i=i+1;  
[dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma);
% dt=1e-4*min(R);  
[vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary);
[vel,dvel,p_ind,dp_ind,grad_p_ind,pos,i_mir,alpha_i] = two_parallerwalls(t,R,pos,Rt,vel,dvel,p_ind,dp_ind,grad_p_ind,i);
Pamb=Pref+rho*abs(g(3))*abs(pos(:,3));
[R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration);

Rt(1:ibubble,i,1)=t; Rt(1:ibubble,i,2)=R(1:ibubble); Rt(1:ibubble,i,3)=dR(1:ibubble); Rt(1:ibubble,i,4)=ddR(1:ibubble);
Rt(1:ibubble,i,5)=HH(1:ibubble); Rt(1:ibubble,i,6)=dHH(1:ibubble);
Ru(1:ibubble,i,1)=u(1:ibubble,1);Ru(1:ibubble,i,2)=u(1:ibubble,2);Ru(1:ibubble,i,3)=u(1:ibubble,3);
t=t+dt
[p_field_com,phit,uuf] = cal_pressure_mixed(pos,i_mir,alpha_i,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com);

% [iDD]=judge_dist(R,pos,boundary,boun_pos,norm_boun);
% if iDD~=0; 
%     fprintf('Please check the distance of bubbles');
%     break 
% end  
     
end

while(boundary==23&&t<Tend)    %%%%%% mixed   
i=i+1;  
[dt] = caldt(sdt,Pamb,rho,P0,R0,R,dR,gamma);
dt=1e-4*min(R);  
[vel,dvel,p_ind,dp_ind,grad_p_ind] = iniduced_information(ibubble,pos,R,c,Tend,i,t,Rt,rho,boundary);
[vel,dvel,p_ind,dp_ind,grad_p_ind,pos,i_mir,alpha_i,dis_bt0,dis_b0,dis_v0] = mixed_walls(t,R,pos,Rt,Ru,vel,dvel,p_ind,dp_ind,grad_p_ind,i,dis_bt0,dis_b0,dis_v0);
Pamb(1:ibubble)=Pref+rho*abs(g(3))*abs(pos(1:ibubble,3));
[R,dR,u,du,HH,dHH,ddu,ddR,pos] = solver(P0,R0,Pamb,p_ind,dp_ind,dvel,vel,grad_p_ind,dt,ddR,ddu,dR,du,R,u,pos,migration);

Rt(1:ibubble,i,1)=t; Rt(1:ibubble,i,2)=R(1:ibubble); Rt(1:ibubble,i,3)=dR(1:ibubble); Rt(1:ibubble,i,4)=ddR(1:ibubble);
Rt(1:ibubble,i,5)=HH(1:ibubble); Rt(1:ibubble,i,6)=dHH(1:ibubble);
Ru(1:ibubble,i,1)=u(1:ibubble,1);Ru(1:ibubble,i,2)=u(1:ibubble,2);Ru(1:ibubble,i,3)=u(1:ibubble,3);
t=t+dt
[p_field_com,phit,uuf] = cal_pressure_mixed(pos,i_mir,alpha_i,pressure_loc,R,dR,HH,Rt,t,i,phit,uuf,p_field_com);

end

% figure
% plot(Rt(1,2:i-1,1)*1e0,Rt(1,2:i-1,2)*1e0,'linewidth',2)
% 
% figure
% plot(Rt(1,2:i-1,1)*1e0,Ru(1,2:i-1,2)*1e0,'linewidth',2)
% 
% figure
% plot(Rt(1,2:i-1,1)*1e0,Rt(1,2:i-1,2)*1e0,'linewidth',2)
plott(ibubble,Rt,i,Ru,p_field_com);





